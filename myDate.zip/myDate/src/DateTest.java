import javax.swing.*;

public class DateTest {
    public static void accept() {
        boolean check;
        do {
            check = true;
            String string_date = JOptionPane.showInputDialog(null, "Input the date:");
            try {
                MyDate date = new MyDate().accept(string_date);
                JOptionPane.showMessageDialog(null,"Today is: " + date.getMonth() + " " + date.getDay() + ", " + date.getYear());
            } catch (MonthFormatException e) {
                JOptionPane.showMessageDialog(null,"Month!");
                check = false;
            } catch (LunarYearException e) {
                JOptionPane.showMessageDialog(null,"Lunar!");
                check = false;
            } catch (DayFormatException e) {
                JOptionPane.showMessageDialog(null,"Day!");
                check = false;
            } catch (YearFormatExceprion e) {
                JOptionPane.showMessageDialog(null,"Year!");
                check = false;
            } catch (Exception e) {
                return;
            }
        } while (!check);
    }

    public static void print() {
        MyDate current = new MyDate();
        JOptionPane.showMessageDialog(null,"Today is: " + current.getMonth() + " " + current.getDay() + ", " + current.getYear());
    }

    public static void main(String[] args) throws Exception {
        accept();
        print();
    }
}
