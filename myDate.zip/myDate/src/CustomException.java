class MonthFormatException extends Exception{
    public MonthFormatException(String error) {
        super(error);
    }
    public MonthFormatException() {

    }
}
class DayFormatException extends Exception {
    public DayFormatException(String error) {
        super(error);
    }
    public DayFormatException() {

    }
}
class YearFormatExceprion extends Exception {
    public YearFormatExceprion(String error) {
        super(error);
    }
    public YearFormatExceprion() {

    }
}
class LunarYearException extends Exception {
    public LunarYearException(String error) {
        super(error);
    }
    public LunarYearException() {

    }
}