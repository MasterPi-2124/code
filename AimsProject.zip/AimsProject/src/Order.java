import java.awt.*;
import java.util.*;
import java.util.List;
import javax.swing.*;

public class Order {
    public static final int MAX_NUMBER_ORDERED = 3;

    private List<DigitalVideoDisc> itemsOrdered = new ArrayList<DigitalVideoDisc>();

    public void addDVD(DigitalVideoDisc disc) throws Exception {
        itemsOrdered.add(disc);
        if (itemsOrdered.size() == MAX_NUMBER_ORDERED) {
            throw new Exception();
        }
        System.out.println(itemsOrdered.size());
        System.out.println(itemsOrdered);
    }

    public void removeDVD(String title) throws Exception {
        boolean check = false;
        for (int i = 0; i < itemsOrdered.size(); i++)
        {
            if (title.equals(itemsOrdered.get(i).getTitle())) {
                check = true;
                itemsOrdered.remove(i);
                System.out.println(itemsOrdered.size());
                System.out.println(itemsOrdered);
            }
        }
        if (!check) throw new Exception();
    }

    public float total() {
        float cost = 0;
        for (int i = 0; i < itemsOrdered.size(); i++)
            cost += itemsOrdered.get(i).getCost();
        return cost;
    }
}
