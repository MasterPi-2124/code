import javax.swing.*;
import java.awt.*;

public class Aims {
    private static Order order = new Order();

    public static void add() {
        while (true) {
            JTextField Title = new JTextField();
            JTextField Category = new JTextField();
            JTextField Director = new JTextField();
            JTextField Length = new JTextField();
            JTextField Cost = new JTextField();
            String title = null, category = null, director = null;
            Integer length = null;
            int a = 2;
            Float cost = null;
            Object[] message = {
                    "Title:", Title,
                    "Category:", Category,
                    "Director:", Director,
                    "Length:", Length,
                    "Cost:", Cost,
            };
            boolean check;

            do {
                check = true;
                int option = JOptionPane.showConfirmDialog(null, message, "Enter information of the Disc", JOptionPane.OK_CANCEL_OPTION);
                if (option == JOptionPane.OK_OPTION) {
                    title = Title.getText();
                    category = Category.getText();
                    director = Director.getText();
                    try {
                        length = Integer.parseInt(Length.getText());
                    } catch (NumberFormatException e) {
                        check = false;
                    }
                    try {
                        cost = Float.parseFloat(Cost.getText());
                    } catch (NumberFormatException e) {
                        check = false;
                    }
                    if (!check) JOptionPane.showMessageDialog(null, "Try again.");
                }
                else {
                    JOptionPane.showMessageDialog(null,"Total cost: " + order.total());
                    return;
                }
            } while (!check);
            DigitalVideoDisc disc = new DigitalVideoDisc(title, category, director, length, cost);
            try {
                order.addDVD(disc);
                message = new Object[] {
                        "Your disc has been added successfully!",
                        "Title: " + title,
                        "Category: " + category,
                        "Director: " + director,
                        "Length: " + length,
                        "Cost: " + cost,
                };
                JOptionPane.showMessageDialog(null, message);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null,"The queue is now full. You can't add any more items!");
                JOptionPane.showMessageDialog(null,"Total cost: " + order.total());
                return;
            }
        }
    }
    public static void remove() {
        boolean check = true;
        do {
            String title = JOptionPane.showInputDialog("Input the disc's title you want to delete: ");
            try {
                order.removeDVD(title);
                JOptionPane.showMessageDialog(null,"Disc '" + title + "' is removed.\nTotal cost: " + order.total());
                check = true;
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null,"Disc not found!");
                check = false;
            }
        } while (!check);

    }

    public static void main(String[] args){
        add();
        remove();
    }
}